import SwiftUI

struct OnboardingView: View {
    @State private var isGetStartedButtonTapped = false  // Added state to track button tap
    
    var body: some View {
        VStack {
            Image("onboarding")
                .resizable()
                .scaledToFill()
                .frame(height: 300)
                .clipped()
            
            Spacer()
            
            Text("Welcome to SpotJog")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding(.bottom, 20)
            
            Text("SpotJog helps you store and locate items easily. Just take a picture of an item and we'll remember it for you.")
                .multilineTextAlignment(.center)
                .padding(.horizontal,8)
                .font(.title2)
            
            Spacer()
            
            Button(action: {
                isGetStartedButtonTapped = true
            }) {
                Text("Get Started")
                    .font(.headline)
                    .foregroundColor(.white)
                    .padding()
                    .frame(width: 200, height: 50)
                    .background(Color.blue)
                    .cornerRadius(10)
            }
            .fullScreenCover(isPresented: $isGetStartedButtonTapped, content: {
                MainappView() // Navigate to ContentView when the button is tapped
            })

            Spacer()
        }
        .padding()
    }
}


struct OnboardingView_Previews: PreviewProvider {
    static var previews: some View {
        OnboardingView()
    }
}


           
