import SwiftUI

enum CategoryIcon: String {
    case keys = "key.fill"
    case jewellery = "diamond.circle.fill"
    case medicine = "cross.circle.fill"
    case glasses = "eyeglasses"
    case remote = "iphone.circle.fill"
    case other = "questionmark.circle.fill"

    var systemImageName: String {
        return self.rawValue
    }
}

struct Item: Identifiable {
    var id = UUID()
    var name: String
    var category: String
    var location: String
    var image: Image?
}

class ItemStore: ObservableObject {
    @Published var items: [Item] = []
}

struct MainappView: View {
    @State private var showFindItems = false
    @State private var showStoreItem = false
    @State private var itemName = ""
    @State private var selectedCategory = "Select"
    @State private var locationDescription = ""
    @State private var itemImage: Image?
    @State private var selectedImage: UIImage?
    @State private var selectedItem: Item?

    @ObservedObject var itemStore = ItemStore()

    var body: some View {
        NavigationView {
            VStack {
                HStack {
                    Button(action: {
                        showFindItems.toggle()
                    }) {
                        Label("Find Items", systemImage: "magnifyingglass")
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.blue)
                            .cornerRadius(10)
                    }
                    .buttonStyle(MainButtonStyle())
                    .sheet(isPresented: $showFindItems) {
                        FindItemsView(items: itemStore.items, selectedItem: $selectedItem, itemStore: itemStore)
                    }

                    Button(action: {
                        showStoreItem.toggle()
                    }) {
                        Label("Store Items", systemImage: "plus.circle")
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.blue)
                            .cornerRadius(10)
                    }
                    .buttonStyle(MainButtonStyle())
                    .sheet(isPresented: $showStoreItem) {
                        StoreItemView(
                            itemName: $itemName,
                            selectedCategory: $selectedCategory,
                            locationDescription: $locationDescription,
                            itemImage: $itemImage,
                            selectedImage: $selectedImage,
                            itemStore: itemStore
                        )
                        .background(Color.white)
                    }
                }
                .padding()

                Text("Recently Added")
                    .font(.headline)
                    .padding()

                List(itemStore.items.prefix(3)) { item in
                    NavigationLink(destination: ItemDetailsView(item: item).environmentObject(itemStore)) {
                        ItemListItemView(item: item)
                            .onTapGesture {
                                self.selectedItem = item
                            }
                    }
                }
                .listStyle(PlainListStyle())

                Spacer()
            }
            .navigationTitle("SpotJog")
        }
    }
}

struct FindItemsView: View {
    var items: [Item]
    @Binding var selectedItem: Item?
    @State private var searchText = ""
    var itemStore: ItemStore

    var filteredItems: [Item] {
        if searchText.isEmpty {
            return items
        } else {
            return items.filter { $0.name.localizedCaseInsensitiveContains(searchText) }
        }
    }

    var body: some View {
        NavigationView {
            VStack {
                Text("Find Items")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .padding()

                SearchBar(text: $searchText)

                List {
                    ForEach(filteredItems) { item in
                        NavigationLink(destination: ItemDetailsView(item: item).environmentObject(itemStore)) {
                            ItemListItemView(item: item)
                        }
                    }
                    .onDelete(perform: deleteItem)
                }
                .listStyle(PlainListStyle())
            }
            .navigationBarItems(leading: Text(""))
            .navigationBarHidden(true)
        }
    }

    private func deleteItem(at offsets: IndexSet) {
        guard let index = offsets.first else { return }
        itemStore.items.removeAll { $0.id == filteredItems[index].id }
    }
}

struct ItemListItemView: View {
    let item: Item

    var body: some View {
        HStack {
            Image(systemName: iconForCategory(item.category))
                .resizable()
                .frame(width: 40, height: 40)
                .foregroundColor(.blue)
                .padding(.trailing, 8)

            VStack(alignment: .leading) {
                Text(item.name)
                    .font(.headline)
                Text("Category: \(item.category)")
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }
        }
        .padding(8)
    }

    private func iconForCategory(_ category: String) -> String {
        switch category.lowercased() {
        case "keys":
            return CategoryIcon.keys.systemImageName
        case "jewellery":
            return CategoryIcon.jewellery.systemImageName
        case "medicine":
            return CategoryIcon.medicine.systemImageName
        case "glasses":
            return CategoryIcon.glasses.systemImageName
        case "remote":
            return CategoryIcon.remote.systemImageName
        default:
            return CategoryIcon.other.systemImageName
        }
    }
}

struct ItemDetailsView: View {
    @EnvironmentObject var itemStore: ItemStore
    @State private var isEditing = false
    @State private var showAlert = false

    var item: Item

    var body: some View {
        VStack {
            if let itemImage = item.image {
                itemImage
                    .resizable()
                    .scaledToFit()
                    .frame(height: 200)
                    .cornerRadius(10)
                    .padding(.bottom, 16)
            } else {
                Image(systemName: "photo")
                    .resizable()
                    .scaledToFit()
                    .frame(height: 200)
                    .foregroundColor(.gray)
                    .cornerRadius(10)
                    .padding(.bottom, 16)
            }

            Text("Name: \(item.name)")
                .font(.title)
                .padding(.bottom, 8)

            Text("Category: \(item.category)")
                .font(.title)
                .padding(.bottom, 8)

            Text("Location: \(item.location)")
                .font(.title)
                .padding(.bottom, 16)

            HStack(spacing: 16) {
                Button(action: {
                    isEditing = true
                }) {
                    Text("Edit")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.blue)
                        .cornerRadius(10)
                }
                .sheet(isPresented: $isEditing) {
                    EditItemView(item: item)
                        .environmentObject(itemStore)
                }

                Button(action: {
                    showAlert = true
                }) {
                    Text("Delete")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.red)
                        .cornerRadius(10)
                }
                .alert(isPresented: $showAlert) {
                    Alert(
                        title: Text("Confirm Deletion"),
                        message: Text("Are you sure you want to delete this item?"),
                        primaryButton: .destructive(Text("Delete")) {
                            if let index = itemStore.items.firstIndex(where: { $0.id == item.id }) {
                                itemStore.items.remove(at: index)
                            }
                        },
                        secondaryButton: .cancel()
                    )
                }
            }
            .padding(.top, 16)

            Spacer()
        }
        .padding()
        .navigationTitle("Item Details")
    }
}

struct EditItemView: View {
    @EnvironmentObject var itemStore: ItemStore
    @State private var editedItem: Item

    init(item: Item) {
        _editedItem = State(initialValue: item)
    }

    var body: some View {
        Form {
            Section(header: Text("Item Details").font(.title2).foregroundColor(.blue)) {
                TextField("Name", text: $editedItem.name)
                    .font(.title3)

                Picker("Category", selection: $editedItem.category) {
                    ForEach(["Select", "Keys", "Jewellery", "Medicine", "Glasses", "Remote", "Other"], id: \.self) {
                        Text($0)
                    }
                }
                .pickerStyle(WheelPickerStyle())

                TextField("Location", text: $editedItem.location)
                    .font(.title3)
            }

            Section {
                Button(action: {
                    if let index = itemStore.items.firstIndex(where: { $0.id == editedItem.id }) {
                        itemStore.items[index] = editedItem
                    }
                }) {
                    Text("Save Changes")
                        .font(.title2)
                        .foregroundColor(.white)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.blue)
                        .cornerRadius(10)
                        .padding(.horizontal, 20)
                }
            }
        }
        .navigationTitle("Edit Item")
    }
}

struct StoreItemView: View {
    @Binding var itemName: String
    @Binding var selectedCategory: String
    @Binding var locationDescription: String
    @Binding var itemImage: Image?
    @Binding var selectedImage: UIImage?

    @ObservedObject var itemStore: ItemStore
    @State private var showImagePicker = false
    @State private var showAlert = false
    @State private var capturedImage: Image?

    @State private var isNameValid = true
    @State private var isLocationValid = true

    var categories = ["Select", "Keys", "Jewellery", "Medicine", "Glasses", "Remote", "Other"]

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Item Details").font(.title2).foregroundColor(.blue)) {
                    TextField("Name", text: $itemName)
                        .font(.title3)
                        .onChange(of: itemName) { newValue in
                            isNameValid = !newValue.isEmpty
                        }
                        .background(isNameValid ? Color.clear : Color.red.opacity(0.3))
                        .cornerRadius(8)
                        .padding(.bottom, 8)

                    Picker("Category", selection: $selectedCategory) {
                        ForEach(categories, id: \.self) {
                            Text($0)
                        }
                    }
                    .pickerStyle(WheelPickerStyle())

                    TextField("Location", text: $locationDescription)
                        .font(.title3)
                        .onChange(of: locationDescription) { newValue in
                            isLocationValid = !newValue.isEmpty
                        }
                        .background(isLocationValid ? Color.clear : Color.red.opacity(0.3))
                        .cornerRadius(8)
                        .padding(.bottom, 8)

                    HStack {
                        Text("Capture Image")
                            .foregroundColor(.blue)
                            .font(.headline)
                            .padding(.trailing, 8)

                        Spacer()

                        Button(action: {
                            showImagePicker.toggle()
                        }) {
                            Image(systemName: "camera.fill")
                                .foregroundColor(.blue)
                                .font(.headline)
                        }
                        .sheet(isPresented: $showImagePicker) {
                            ImagePicker(image: $selectedImage, sourceType: .camera)
                        }
                    }

                    if let capturedImage = capturedImage {
                        capturedImage
                            .resizable()
                            .scaledToFit()
                            .frame(height: 100)
                    }
                }

                Section {
                    Button(action: {
                        if selectedCategory == "Select" || !isNameValid || !isLocationValid {
                            showAlert = true
                            return
                        }

                        let newItem = Item(name: itemName, category: selectedCategory, location: locationDescription, image: itemImage)
                        itemStore.items.append(newItem)
                        itemName = ""
                        selectedCategory = "Select"
                        locationDescription = ""
                        itemImage = itemFromUIImage(uiImage: selectedImage)
                        selectedImage = nil

                        if let uiImage = selectedImage {
                            capturedImage = Image(uiImage: uiImage)
                        }
                    }) {
                        Text("Add Item")
                            .font(.title2)
                            .foregroundColor(.white)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.green)
                            .cornerRadius(10)
                            .padding(.horizontal, 20)
                    }
                }
            }
            .navigationTitle("Store Item")
            .alert(isPresented: $showAlert) {
                Alert(
                    title: Text("Validation Error"),
                    message: Text("Please fill in all required fields."),
                    dismissButton: .default(Text("OK"))
                )
            }
        }
        .background(Color.white)
    }

    private func itemFromUIImage(uiImage: UIImage?) -> Image? {
        guard let uiImage = uiImage else {
            return nil
        }
        return Image(uiImage: uiImage)
    }
}

struct ImagePicker: UIViewControllerRepresentable {
    @Binding var image: UIImage?
    var sourceType: UIImagePickerController.SourceType

    class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
        @Binding var image: UIImage?

        init(image: Binding<UIImage?>) {
            _image = image
        }

        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let uiImage = info[.originalImage] as? UIImage {
                image = uiImage
            }

            picker.dismiss(animated: true)
        }

        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            picker.dismiss(animated: true)
        }
    }

    func makeCoordinator() -> Coordinator {
        return Coordinator(image: $image)
    }

    func makeUIViewController(context: UIViewControllerRepresentableContext<ImagePicker>) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.delegate = context.coordinator
        picker.sourceType = sourceType
        return picker
    }

    func updateUIViewController(_ uiViewController: UIImagePickerController, context: UIViewControllerRepresentableContext<ImagePicker>) {
        // No op
    }
}

struct MainButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.title2)
            .padding()
            .foregroundColor(.white)
            .background(configuration.isPressed ? Color.gray : Color.blue)
            .cornerRadius(10)
    }
}

struct SearchBar: View {
    @Binding var text: String

    var body: some View {
        HStack {
            TextField("Search", text: $text)
                .padding(8)
                .background(Color(.systemGray6))
                .cornerRadius(8)
                .padding(.horizontal)

            Button(action: {
                self.text = ""
            }) {
                Image(systemName: "xmark.circle.fill")
                    .foregroundColor(.gray)
                    .padding(8)
            }
            .opacity(text.isEmpty ? 0 : 1)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        MainappView()
    }
}

struct ItemDetailsView_Previews: PreviewProvider {
    static var previews: some View {
        let itemStore = ItemStore()
        itemStore.items = [
            Item(name: "Sample Item 1", category: "Keys", location: "Living Room", image: nil),
            Item(name: "Sample Item 2", category: "Jewellery", location: "Bedroom", image: nil),
            Item(name: "Sample Item 3", category: "Medicine", location: "Kitchen", image: nil)
        ]

        return NavigationView {
            ItemDetailsView(item: itemStore.items[0])
                .environmentObject(itemStore)
        }
    }
}
